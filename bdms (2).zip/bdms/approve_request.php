<?php
include 'conn.php';

$requestId = $_POST['requestId'];

$sql = "UPDATE blood_requests SET status = 'Approved' WHERE request_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $requestId);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database update failed']);
}
