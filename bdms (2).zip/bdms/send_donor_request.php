<?php
include 'conn.php';

$donorId = $_POST['donorId'];
$bloodBankId = $_POST['bloodBankId'];
$bloodBankName = $_POST['bloodBankName'];
$bloodBankContact = $_POST['bloodBankContact'];
$donorContact = $_POST['donorContact']; 
$donorName = $_POST['donorName'];

// Prepare and execute SQL statement
$sql = "INSERT INTO donor_requests (donor_id, blood_bank_id, blood_bank_name, blood_bank_contact, donor_contact, donor_name)  VALUES (?, ?, ?, ?, ?, ?)"; 
$stmt = $conn->prepare($sql);
$stmt->bind_param("iisss", $donorId, $bloodBankId, $bloodBankName, $bloodBankContact, $donorContact, $donorName);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}