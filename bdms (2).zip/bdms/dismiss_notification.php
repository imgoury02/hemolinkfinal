<?php
include 'conn.php';

// Get notification ID from AJAX request 
$notificationId = $_POST['notificationId'];

// Update the notification in the database
$sql = "UPDATE donor_requests SET dismissed = true WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $notificationId);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}
