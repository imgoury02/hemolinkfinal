<?php
// Check if a session is already started before calling session_start()
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Rest of your session.php code follows
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Blood Bank Dashboard</title>
     <style>
     #sidebar { position: relative; margin-top: -20px; }
        #content { position: relative; margin-left: 210px; }
        @media screen and (max-width: 600px) {
            #content { position: relative; margin-left: 300px; margin-right: auto; }
        }
        .block-anchor { color: red; cursor: pointer; }

        /* General Table Styling */
        table {
            border-collapse: collapse;
            width: 80%;
            margin-top: 20px;
            margin-left: 150px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        thead {
            background-color: black; /* Black background for the header */
        }

        thead th {
            color: white; /* White text for header cells */
            padding: 12px 15px; /* Slightly larger padding for header cells */
            text-align: left;
        }

        tbody {
            background-color: #f0f0f0; /* Light grey background for table body */
        }

        tbody th, tbody td {
            color: black; /* Black text for body cells */
            padding: 12px 15px; /* Slightly larger padding for table cells */
            text-align: left;
            border-bottom: 1px solid #ddd; /* Light grey border for table cells */
        }

        tbody tr:hover {
            background-color: #f1f1f1; /* Light grey background on row hover */
        }

        /* Styling for Done Buttons */
        .done-btn {
            background-color: #4CAF50; /* Green background for done button */
            color: white; /* White text for done button */
            padding: 8px 12px; /* Padding for done button */
            text-align: center;
            text-decoration: none;
            display: inline-block;
            border-radius: 4px; /* Rounded corners for done button */
            border: none;
            cursor: pointer;
        }

        /* Styling for Request Donation Buttons */
        .request-btn {
            background-color: black; /* Black background for request donation button */
            color: white; /* White text for request donation button */
            padding: 8px 12px; /* Padding for request donation button */
            text-align: center;
            text-decoration: none;
            display: inline-block;
            border-radius: 4px; /* Rounded corners for request donation button */
            border: none;
            cursor: pointer;
        }

        /* Styling for Filter Button */
        .filter-btn {
            background-color: black; /* Black background for filter button */
            color: white; /* White text for filter button */
            padding: 8px 12px; /* Padding for filter button */
            text-align: center;
            text-decoration: none;
            display: inline-block;
            border-radius: 4px; /* Rounded corners for filter button */
            border: none;
            cursor: pointer;
        }

        /* Styling for Select Dropdown */
        select {
            padding: 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
            margin-right: 10px;
        }
    </style>
</head>
<body style="color:black;">
    <?php
    include 'conn.php';  
    include 'session.php'; 
    ?>

    <div id="header">
        <?php include 'bbheader.php'; ?>
    </div>

    <div id="sidebar">
        <?php
        $active="donor_management";
        include 'bbsidebar.php'; ?>
    </div>
    <div id=content>
    <br>
    <form id="filterForm"> 
    <select name="bloodGroup" id="bloodGroup">
        <option value="">-- Select Blood Group --</option>
        <option value="">Show All</option>
        <option value="A+">A+</option>
        <option value="B+">B+</option>
        <option value="B-">B-</option>
        <option value="A-">A-</option>
        <option value="AB+">AB+</option>
        <option value="AB-">AB-</option>
        <option value="O+">O+</option>
        <option value="O-">O-</option>
        </select>
    <button type="submit" class="filter-btn">Filter</button> 
    </form>
    <table id="donorTable">
    <thead>
        <tr>
            <th>Name</th>
            <th>Blood Group</th>
            <th>Last Donated</th> 
            <th>Actions</th>
            <th>Done</th>
        </tr>
    </thead>
    <tbody>
        <?php include 'fetch_donors.php'; ?> 
    </tbody>
</table>
    </div>
    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function() {

        $('#filterForm').submit(function(event) {
        event.preventDefault(); // Prevent default form submission

        const bloodGroup = $('#bloodGroup').val();

        $.ajax({
            url: 'filter_donor.php',
            type: 'POST',
            data: { bloodGroup: bloodGroup },
            success: function(response) { 
                // Replace existing donor list with new HTML from 'filter_donors.php'
                $('#donorTable').html(response); 
            }
        });
    });
    $('.done-btn').click(function() {
    const donorId = $(this).data('donor-id'); 
    if (confirm("Are you sure you want to mark this donation as done?")) {  // Confirmation dialog
        $.ajax({
            url: 'mark_donation_done.php', 
            type: 'POST',
            data: { donorId: donorId },
            success: function(response) {
                if (response.status === 'success') {
                    alert("Donation marked as done!");
                   // Optionally update the frontend (disable buttons, change display, etc.)
                } else {
                    console.error("Error updating donation:", response.message); 
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error); 
            }
        });
    }
});
$('.request-btn').click(function() {
    const donorContact = $(this).data('donor-contact');
    const donorName = $(this).data('donor-name'); 
    const bloodBankName = $(this).data('blood-bank-name');
    const bloodBankCity = $(this).data('blood-bank-city');
    const bloodBankContact = $(this).data('blood-bank-contact');
    const bloodBankId = $(this).data('blood-bank-id');  

    // ... your existing button behavior (disabling, display changes) ...

    $.ajax({
        url: 'send_donation_request.php',
        type: 'POST',
        data: { 
            donorContact: donorContact,  
            donorName: donorName,
            bloodBankName: bloodBankName,
            bloodBankCity: bloodBankCity,
            bloodBankContact: bloodBankContact,
            bloodBankId: bloodBankId
        },
        success: function(response) {
            alert("SMS Message Sent"); // A simple success message
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", error); // Log the error for debugging
            alert("Error sending SMS. Please try again.");
        }
    });
});

    });

    </script> 
</html>
