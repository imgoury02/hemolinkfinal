<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style>
body {
  margin: 0;
font-family: 'Averia Gruesa Libre';font-size: 15px;
    color:#F8F9F9;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 210px;
  background-color: #333333;
  position: fixed;
  height: 100%;
  overflow: auto;

}

.sidebar a {
  display: block;
  color: white;

  padding: 16px;
  text-decoration: none;
}



.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 250px;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}
a.act{
background: linear-gradient(to right, #00C9FF 0%, #92FE9D 100%);
color: black;
border-radius:10px;
}


@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
</style>
</head>
<body>

<div class="sidebar">
    <a href="bbdash.php" <?php if($active=='dashboard') echo "class='act'"; ?>>
        <span class="glyphicon glyphicon-dashboard"></span>&nbsp&nbsp Dashboard
    </a>
    <a href="blood_inventory_overview.php" <?php if($active=='inventory') echo "class='act'"; ?>>
        <span class="glyphicon glyphicon-tint"></span>&nbsp&nbsp Blood Inventory Overview
    </a>
    <a href="hospital_blood_requests.php" <?php if($active=='requests') echo "class='act'"; ?>>
        <span class="glyphicon glyphicon-heart"></span>&nbsp&nbsp Hospital Blood Requests
    </a>
    <a href="donor_management.php" <?php if($active=='donor_management') echo "class='act'"; ?>>
        <span class="glyphicon glyphicon-user"></span>&nbsp&nbsp Donor Management
    </a>
</div>
