<?php
include 'conn.php';

$bloodGroup = $_POST['bloodGroup'];
$eligibleDate = date('Y-m-d', strtotime('-4 months'));
// Add blood group filtering
if (empty($bloodGroup)) {
    $sql = "SELECT * FROM donors WHERE last_donated <= ?"; // No filter on blood group
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $eligibleDate);
} else{
$sql = "SELECT * FROM donors 
        WHERE blood_group = ? AND last_donated <= ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $bloodGroup, $eligibleDate); 
}
$stmt->execute();
$result = $stmt->get_result();
$donors = $result->fetch_all(MYSQLI_ASSOC);
// ... rest of your code to execute, fetch results, and generate HTML output
$htmlOutput = "<table>";
$htmlOutput .= "<thead><tr><th>Name</th><th>Blood Group</th><th>Last Donated</th><th>Actions</th><th>Done</th></tr></thead>";
$htmlOutput .= "<tbody>";

foreach ($donors as $donor) {
    $htmlOutput .= "<tr>";
    $htmlOutput .= "<td>" . $donor['name'] . "</td>";
    $htmlOutput .= "<td>" . $donor['blood_group'] . "</td>"; 
    $htmlOutput .= "<td>" . $donor['last_donated'] . "</td>"; // Assuming you have a phone_number column
    $htmlOutput .= "<td><button class='request-btn1' data-donor-id='" . $donor['id'] . "'>Request Donation</button></td>";
    $htmlOutput .="<td><button class='done-btn1' data-donor-id='" . $donor['id'] . "'>Done</button></td>";
    $htmlOutput .= "</tr>";
}

$htmlOutput .= "</tbody></table>";

// Send the HTML back to the AJAX request
echo $htmlOutput;

