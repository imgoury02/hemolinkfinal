<?php
    use Infobip\Configuration;
    use Infobip\Api\SmsApi;
    use Infobip\Model\SmsDestination;
    use Infobip\Model\SmsTextualMessage;
    use Infobip\Model\SmsAdvancedTextualRequest;
    
    require __DIR__ . "/vendor/autoload.php";
    $bloodBankId = $_POST['blood-bank-id'];
    $bloodBankName = $_POST['blood-bank-me'];
    $bloodBankCity = $_POST['blood-bank-city'];
    $donorName = $_POST['donor-name'];
    $donorContact = $_POST['donor-contact'];
    $bloodBankContact = $_POST['blood-bank-contact'];

    $apiURL = "qy2j8q.api.infobip.com";
    $apiKey = "d0560493283ebf173a77bc64548a51c4-05124b95-291a-4cb8-99af-1a1ee79dadfb";

    $configuration = new Configuration(host: $apiURL, apiKey: $apiKey);
    $api = new SmsApi(config: $configuration);

    $destination = new SmsDestination(to: $donorContact);
    $theMessage = new SmsTextualMessage(
        destinations: [$destination],
        text: "Hello $donorName, $bloodBankName from $bloodBankCity is in an urgency to request blood of your blood group.
        Please contact $bloodBankName at $bloodBankContact for further details. A blood donation can change a life.",
        from: "Syntax Flow"
    );

    $request = new SmsAdvancedTextualRequest(messages: [$theMessage]);
    $response = $api->sendSmsMessage($request);
    echo "SMS Message Sent";

    