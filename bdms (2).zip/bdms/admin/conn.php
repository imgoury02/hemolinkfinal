<?php
$conn=mysqli_connect("localhost","root","Athi@2003","cloud_bank") or die("Connection error");
?>
