<?php
include 'conn.php'; 
include 'session.php'; // Assuming session handling for user_id

// Retrieve blood bank ID associated with the user
$userID = $_SESSION['user_id']; 
$sql = "SELECT id FROM blood_banks WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $userID);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 1) {
  $row = mysqli_fetch_assoc($result);
  $bloodbankID = $row['id'];
} else {
  // Handle the case where no blood bank is found (e.g., display an error message)
  echo "Error: No blood bank found for this user.";
  exit; // Might want to stop execution 
}

// Validate blood type
$bloodTypeEdit = $_POST['bloodTypeEdit'];
$validBloodTypes = array("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-");

if (!in_array($bloodTypeEdit, $validBloodTypes)) {
  echo "Error: Invalid blood type. Please enter one of the following: A+, A-, B+, B-, O+, O-, AB+, AB-.";
  exit; // Stop execution on invalid blood type
}

// Check if blood type already exists (same logic as before)
$sql = "SELECT COUNT(*) FROM blood_inventory WHERE blood_type = ? AND blood_bank_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "si", $bloodTypeEdit, $bloodbankID);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$row = mysqli_fetch_assoc($result);
$existingCount = $row['COUNT(*)'];

if ($existingCount > 0) {
  // Blood type already exists, display a popup message
  echo "<script>alert('Blood type ' . '$bloodTypeEdit' . ' already exists in your inventory.');</script>";
} else {
  // Blood type is valid and doesn't exist, proceed with insertion
  $quantityEdit = $_POST['quantityEdit'];

  $stmt = $conn->prepare("INSERT INTO blood_inventory (blood_type, quantity, blood_bank_id) VALUES (?, ?, ?)");
  mysqli_stmt_bind_param($stmt, "sii", $bloodTypeEdit, $quantityEdit, $bloodbankID); 

  if ($stmt->execute()) {
    echo json_encode(array("success" => true)); 
  } else {
    $errorMessage = "Error adding inventory: " . $stmt->error . " - " . mysqli_error($conn);
    echo json_encode(array("success" => false, "error" => $errorMessage));
  }
}
?>
