<?php
include 'conn.php'; 
include 'session.php'; // Assuming session handling for user_id

// Retrieve blood bank ID associated with the user
$userID = $_SESSION['user_id']; 
$sql = "SELECT id FROM hospitals WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $userID);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $hospitalID = $row['id'];
} else {
    // Handle the case where no blood bank is found (e.g., display an error message)
    echo "Error: No hospitals found for this user.";
    exit; // Might want to stop execution 
}

// Now proceed with your existing inventory insert code
$bloodType = $_POST['bloodType'];
$quantity = $_POST['quantity'];
$patient_id = $_POST['patient_id'];
$notes = $_POST['notes'];
$status='Pending';
$stmt = $conn->prepare("INSERT INTO blood_requests (blood_type, quantity, patient_id, status , notes, hospital_id) VALUES (?, ?, ?, ?,?, ?)");
mysqli_stmt_bind_param($stmt, "sisssi", $bloodType, $quantity, $patient_id, $status, $notes, $hospitalID); 

if ($stmt->execute()) {
    echo "Request added successfully"; 
} else {
    echo "Error adding request: " . $stmt->error . " - " . mysqli_error($conn);
}
?>