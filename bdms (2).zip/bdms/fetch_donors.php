<?php
include 'conn.php';

$sql = "SELECT id, name, blood_group, last_donated 
        FROM donors WHERE last_donated <= DATE_SUB(CURDATE(), INTERVAL 4 MONTH)";

$result = $conn->query($sql); 

if ($result) {
    while ($donor = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $donor['name'] . "</td>";
        echo "<td>" . $donor['blood_group'] . "</td>";
        echo "<td>" . ($donor['last_donated'] ?? 'Never Donated') . "</td>"; 
        echo "<td>";
        echo "<button class='request-btn' data-donor-id='" . $donor['id'] . "'>Request Donation</button>";
        echo "</td>";
        echo "<td>";
        echo "<button class='done-btn' data-donor-id='" . $donor['id'] . "'>Done</button>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='3'>Error fetching donors.</td></tr>"; 
}
