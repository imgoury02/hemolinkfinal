<?php
// Check if a session is already started before calling session_start()
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Rest of your session.php code follows
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Blood Bank Dashboard</title>
     <style>
    /* #sidebar {position:relative;margin-top:-20px}
    #content {position:relative;margin-left:210px}
    @media screen and (max-width: 600px) {
        #content {
            position:relative;margin-left:300px;margin-right:auto;
        }
    }
    .block-anchor {
        color:red;
        cursor: pointer;
    }
    
table {
    border-collapse: collapse; 
    width: 80%; 
    margin-top: 20px; 
    margin-left: 150px;
}

thead, tbody {
    background-color: #f0f0f0; 
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}


.request-approved { 
    background-color: lightgreen;
}

.request-rejected { 
    background-color: #fddddd; 
}

.edit-btn {
    background-color: #4CAF50; 
    color: white;
    padding: 5px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    border-radius: 5px;
    border: none;
    cursor: pointer; 
} */
#sidebar {position:relative;margin-top:-20px}
    #content {position:relative;margin-left:210px}
    @media screen and (max-width: 600px) {
        #content {
            position:relative;margin-left:300px;margin-right:auto;
        }
    }
    .block-anchor {
        color:red;
        cursor: pointer;
    }
    
/* table {
    border-collapse: collapse; 
    width: 80%; 
    margin-top: 20px; 
    margin-left: 150px;
}

thead, tbody {
    background-color: #f0f0f0; 
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}


.request-approved { 
    background-color: lightgreen;
}

.request-rejected { 
    background-color: #fddddd; 
}

.edit-btn {
    background-color: #4CAF50; 
    color: white;
    padding: 5px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    border-radius: 5px;
    border: none;
    cursor: pointer; 
} */
/* General Table Styling */
table {
    border-collapse: collapse; 
    width: 80%; 
    margin-top: 20px; 
    margin-left: 150px;
    background-color: #fff; /* White background for the table */
    box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* Subtle shadow for the table */
    border-radius: 8px; /* Rounded corners for the table */
    overflow: hidden; /* Ensure rounded corners are not affected by overflow */
}

/* Table Header Styling */
thead {
    background-color: black; /* Black background for the header */
}

thead th {
    color: white; /* White text for header cells */
    padding: 12px 15px; /* Slightly larger padding for header cells */
    text-align: left; 
}

/* Table Body Styling */
tbody {
    background-color: #f0f0f0; /* Light grey background for table body */
}

tbody th, tbody td {
    color: black; /* Black text for body cells */
    padding: 12px 15px; /* Slightly larger padding for table cells */
    text-align: left; 
    border-bottom: 1px solid #ddd; /* Light grey border for table cells */
}

/* Table Row Hover Effect */
tbody tr:hover {
    background-color: #f1f1f1; /* Light grey background on row hover */
}

/* Low Stock Warning */
.request-approved { 
    background-color: lightgreen; /* Light green for approved requests */
}

.request-rejected { 
    background-color: #fddddd; /* Light red for rejected requests */
}

/* Styling for Edit Buttons */
.edit-btn {
    background-color: #4CAF50; /* Green background for edit button */
    color: white; /* White text for edit button */
    padding: 8px 12px; /* Padding for edit button */
    text-align: center; 
    text-decoration: none; 
    display: inline-block; 
    border-radius: 4px; /* Rounded corners for edit button */
    border: none; 
    cursor: pointer; 
}

/* Styling for Approve Buttons */
.btn-aprove {
    background-color: #4CAF50; /* Green background for approve button */
    color: white; /* White text for approve button */
    padding: 8px 12px; /* Padding for approve button */
    text-align: center; 
    text-decoration: none; 
    display: inline-block; 
    border-radius: 4px; /* Rounded corners for approve button */
    border: none; 
    cursor: pointer; 
}



    </style>
</head>
<body style="color:black;">
    <?php
    include 'conn.php';  
    include 'session.php'; 
    ?>

    <div id="header">
        <?php include 'bbheader.php'; ?>
    </div>

    <div id="sidebar">
        <?php
        $active="requests";
        include 'bbsidebar.php'; ?>
    </div>
    <div id=content>
  <h2>Blood Requests</h2>

  <table id="bloodRequestsTable">
    <thead>
      <tr>
        <th>Hospital</th>
        <th>Blood Type</th>
        <th>Quantity</th>
        <th>Status</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody> 

    
        <?php 
                if (isset($_SESSION['loggedin']) || $_SESSION['user_type'] == 'blood_bank') { 
                    // Retrieve Blood Bank Details
                    $user_id = $_SESSION['user_id']; 
                    $sql = "SELECT * FROM blood_requests"; 
                    $result = mysqli_query($conn, $sql);

                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $hospitalId = $row['hospital_id'];
                            $hospitalSql = "SELECT name FROM hospitals WHERE id = ?";
                            $stmt = mysqli_prepare($conn, $hospitalSql);
                            mysqli_stmt_bind_param($stmt, "i", $hospitalId);
                            mysqli_stmt_execute($stmt);
                            $hospitalResult = mysqli_stmt_get_result($stmt);

                            $hospitalName = "Unknown"; // Default if not found
                            if (mysqli_num_rows($hospitalResult) > 0) {
                                $hospitalRow = mysqli_fetch_assoc($hospitalResult);
                                $hospitalName = $hospitalRow['name'];
                            }
                            echo "<tr class='request-row' data-request-id='" . $row['request_id'] . "'>";
                            echo "<td>" . $hospitalName . "</td>"; // Replace with how you display the hospital name
                            echo "<td>" . $row['blood_type'] . "</td>";
                            echo "<td>" . $row['quantity'] . " units</td>";
                            echo "<td>" . $row['status'] . "</td>";
                            echo "<td>";
                            echo "<button class='btn btn-aprove' data-request-id='" . $row['request_id'] . "'>Approve</button>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                            echo "<tr><td colspan='6'>No blood requests found.</td></tr>";
                    }
                }
            ?> 
            </tbody>
    </table>
    </div>
    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        
        $(document).ready(function() {
    $('.btn-aprove').click(function() {
        const requestId = $(this).data('request-id');
        const button = $(this); 
        const statusColumn = button.closest('tr').find('td:eq(3)'); // Target the 4th <td>

        $.ajax({
            url: 'approve_request.php',
            type: 'POST',
            data: { requestId: requestId },
            success: function(response) {
                console.log("Full Response:", response);
                if (response.status === 'success') {
                    statusColumn.text('Approved'); 
                    button.prop('disabled', true); 
                } else {
                    console.error("Error approving request:", response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error); 
            }
        });
    });
});
        
    </script> 
</html>
