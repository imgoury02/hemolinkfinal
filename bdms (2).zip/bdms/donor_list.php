<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Blood Bank Dashboard</title> <style>
    #sidebar {position:relative;margin-top:-20px}
    #content {position:relative;margin-left:210px}
    @media screen and (max-width: 600px) {
        #content {
            position:relative;margin-left:300px;margin-right:auto;
        }
    }
    .block-anchor {
        color:red;
        cursor: pointer;
    }
    /* General Table Styling */
table {
    border-collapse: collapse; 
    width: 80%; 
    margin-top: 20px; 
    margin-left: 150px;
}

thead, tbody {
    background-color: #f0f0f0; 
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

/* Optional: Styling for Edit Buttons  */
.edit-btn {
    background-color: #4CAF50; /* Green */
    color: white;
    padding: 5px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    border-radius: 5px;
    border: none;
    cursor: pointer; 
}
#donorTable {
    border-collapse: collapse; 
    width: 80%; 
}

#donorTable th, #donorTable td {
    border: 1px solid #ddd;
    padding: 8px;
}
    </style>
</head>
<body style="color:black;">
    <?php
    include 'conn.php';  
    include 'session.php'; 
    ?>

    <div id="header">
        <?php include 'bbheader.php'; ?>
    </div>

    <div id="sidebar">
        <?php
        $active="donor_management";
        include 'bbsidebar.php'; ?>
    </div>
    <div id=content>
    <form id="filterForm"> 
    <select name="bloodGroup" id="bloodGroup">
        <option value="">-- Select Blood Group --</option>
        <option value="">Show All</option>
        <option value="A+">A+</option>
        <option value="B+">B+</option>
        <option value="B-">B-</option>
        <option value="A-">A-</option>
        <option value="AB+">AB+</option>
        <option value="AB-">AB-</option>
        <option value="O+">O+</option>
        <option value="O-">O-</option>
        </select>
    <button type="submit">Filter</button> 
    </form>
    <table id="donorTable">
    <thead>
        <tr>
            <th>Name</th>
            <th>Blood Group</th>
            <th>Last Donated</th> 
            <th>Actions</th>
            <th>Done</th>
        </tr>
    </thead>
    <tbody>
        <?php include 'fetch_donors.php'; ?> 
    </tbody>
</table>
    </div>
    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function() {

        $('#filterForm').submit(function(event) {
        event.preventDefault(); // Prevent default form submission

        const bloodGroup = $('#bloodGroup').val();

        $.ajax({
            url: 'filter_donor.php',
            type: 'POST',
            data: { bloodGroup: bloodGroup },
            success: function(response) { 
                // Replace existing donor list with new HTML from 'filter_donors.php'
                $('#donorTable').html(response); 
            }
        });
    });
    $('.done-btn').click(function() {
    const donorId = $(this).data('donor-id'); 
    if (confirm("Are you sure you want to mark this donation as done?")) {  // Confirmation dialog
        $.ajax({
            url: 'mark_donation_done.php', 
            type: 'POST',
            data: { donorId: donorId },
            success: function(response) {
                if (response.status === 'success') {
                    alert("Donation marked as done!");
                   // Optionally update the frontend (disable buttons, change display, etc.)
                } else {
                    console.error("Error updating donation:", response.message); 
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error); 
            }
        });
    }
});
$('.request-btn').click(function() {
    const donorContact = $(this).data('donor-contact');
    const donorName = $(this).data('donor-name'); 
    const bloodBankName = $(this).data('blood-bank-name');
    const bloodBankCity = $(this).data('blood-bank-city');
    const bloodBankContact = $(this).data('blood-bank-contact');
    const bloodBankId = $(this).data('blood-bank-id');  

    // ... your existing button behavior (disabling, display changes) ...

    $.ajax({
        url: 'send_donation_request.php',
        type: 'POST',
        data: { 
            donorContact: donorContact,  
            donorName: donorName,
            bloodBankName: bloodBankName,
            bloodBankCity: bloodBankCity,
            bloodBankContact: bloodBankContact,
            bloodBankId: bloodBankId
        },
        success: function(response) {
            alert("SMS Message Sent"); // A simple success message
        },
        error: function(xhr, status, error) {
            console.error("AJAX Error:", error); // Log the error for debugging
            alert("Error sending SMS. Please try again.");
        }
    });
});

    });

    </script> 
</html>
