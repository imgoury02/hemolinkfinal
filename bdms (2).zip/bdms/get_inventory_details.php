<?php
include 'conn.php'; // Assuming your database connection file

$inventoryId = $_POST['inventoryId'];

// Prepare the SQL query with a WHERE clause to fetch specific inventory details 
$sql = "SELECT * FROM blood_inventory WHERE inventory_id = ?"; 
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $inventoryId); 
$stmt->execute();

$result = $stmt->get_result(); // Get the result set

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode($row); // Encode the row as JSON and send it as the response
} else {
    echo "Error retrieving inventory details"; // Handle the case where no data is found
}
