<?php
// Check if a session is already started before calling session_start()
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Rest of your session.php code follows
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Blood Bank Dashboard</title> 
    <style>
    /* #sidebar {position:relative;margin-top:-20px}
    #content {position:relative;margin-left:210px}
    @media screen and (max-width: 600px) {
        #content {
            position:relative;margin-left:300px;margin-right:auto;
        }
    }
    .block-anchor {
        color:red;
        cursor: pointer;
    }
    
table {
    border-collapse: collapse; 
    width: 80%; 
    margin-top: 20px; 
    margin-left: 150px;
}

thead, tbody {
    background-color: #f0f0f0; 
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}


.low-stock {
    background-color: #ffdddd;
}


.edit-btn {
    background-color: #4CAF50; 
    color: white;
    padding: 5px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    border-radius: 5px;
    border: none;
    cursor: pointer; 
}
#editFormContainer {
    z-index: 10; 
} */
table {
    border-collapse: collapse; 
    width: 80%; 
    margin: 20px auto; /* Center the table horizontally */
    background-color: #fff; /* White background */
    box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* Subtle shadow */
    border-radius: 8px; /* Rounded corners */
    overflow: hidden; /* Ensure rounded corners are not affected by overflow */
    position: relative; /* Ensure it respects the surrounding context */
    left: 48%; /* Move it to the center */
    transform: translateX(-50%); /* Center it by adjusting its position */
}

thead {
    background-color: #333; /* Black background for the header */
}

/* th {
    color: white; White text for header cells
} */

 td {
    padding: 12px 15px; /* Slightly larger padding */
    text-align: left; 
    border-bottom: 1px solid #ddd;
    color: black; /* Black text color for table content */
}

tbody tr:hover {
    background-color: #f1f1f1; /* Highlight on hover */
}

/* Low Stock Warning */
.low-stock {
    background-color: #ffdddd; /* Light Red */
}

/* Styling for Edit Buttons */
.edit-btn {
    background-color: #4CAF50; /* Green color */
    color: white;
    padding: 8px 12px; /* More padding for better clickability */
    text-align: center;
    text-decoration: none;
    display: inline-block;
    border-radius: 4px;
    border: none;
    cursor: pointer; 
}

/* Center Add Inventory Button */
#addNewInventory {
    display: block; 
    margin: 20px auto; /* Center horizontally with margin */
    background-color: #333; /* Black background */
    color: white;
    padding: 10px 20px;
    text-align: center;
    border-radius: 4px;
    border: none;
    cursor: pointer;
    font-size: 16px;
}

/* Form Container Styling */
#editFormContainer, #addInventoryFormContainer {
    display: none; /* Initially hidden */
    margin: 20px auto;
    padding: 20px;
    background-color: #fff; /* White background */
    box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* Subtle shadow */
    border-radius: 8px; /* Rounded corners */
    width: 60%;
}

#editForm label, #addInventoryForm label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
}

#editForm input, #addInventoryForm input {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}
.button-container {
        display: flex;
        justify-content: space-between;
    }
 .add-btn {
        background-color: black; 
        color: white; 
        padding: 10px 20px; 
        text-align: center; 
        border-radius: 4px; 
        border: none; 
        cursor: pointer; 
    }

    .cancel-btn {
        background-color: red; 
        color: white; 
        padding: 10px 20px; 
        text-align: center; 
        border-radius: 4px; 
        border: none; 
        cursor: pointer; 
    }


    </style>
</head>
<body style="color:black;">
    <?php
    include 'conn.php';  
    include 'session.php'; 
    ?>

    <div id="header">
        <?php include 'bbheader.php'; ?>
    </div>

    <div id="sidebar">
        <?php
        $active="inventory";
        include 'bbsidebar.php'; ?>
    </div>
    <div id=content>

    <table id="inventoryTable" style="color:#fff;">
        <thead>
            <tr>
                <th>Blood Type</th>
                <th>Quantity</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <div id="editFormContainer" style="display: none;"> 
    <form id="editForm" method="post">
        <input type="hidden" id="inventoryId" name="inventoryId"> 
        <label for="bloodType">Blood Type:</label>
        <input type="text" id="bloodType" name="bloodType"><br><br>

        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity"><br><br>

        <button type="submit">Update</button> 
        <button type="button" id="editFormClose">Cancel</button> 
    </form>
</div>
        <?php 
                if (isset($_SESSION['loggedin']) || $_SESSION['user_type'] == 'blood_bank') { 
                    // Retrieve Blood Bank Details
                    $user_id = $_SESSION['user_id']; 
                    $sql = "SELECT *
                    FROM blood_inventory 
                    JOIN blood_banks ON blood_inventory.blood_bank_id = blood_banks.id 
                    JOIN users ON blood_banks.user_id = users.id
                    WHERE users.id = $user_id";
                    $result = mysqli_query($conn, $sql);

                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $class = ($row['quantity'] <= 10) ? 'low-stock' : '';  
                            echo "<tr class='" . $class . "' data-id='" . $row['inventory_id'] . "'>";
                            echo "<td>" . $row['blood_type'] . "</td>";
                            echo "<td>" . $row['quantity'] . "</td>";
                            echo "<td><button class='edit-btn' data-id='" . $row['inventory_id'] . "'>Edit</button></td>"; 
                            echo "</tr>"; 
                    }} else {
                        echo "<tr><td colspan='4'>No inventory data found.</td></tr>";
                    }}
                ?> 
            </tbody>
    </table>
    <button id="addNewInventory">Add Inventory</button>
    <div id="addInventoryFormContainer" style="display: none;"> 
    <form id="addInventoryForm" method="post">
        <label for="bloodTypeEdit">Blood Type:</label>
        <input type="text" id="bloodTypeEdit" name="bloodTypeEdit"><br><br>

        <label for="quantityEdit">Quantity:</label>
        <input type="number" id="quantityEdit" name="quantityEdit"><br><br>
        <div class="button-container">   <!-- new div-->
            <button type="submit" class="add-btn">Add Inventory</button>  <!-- new class name add-btn-->
            <button type="button" class="cancel-btn" id="addFormClose">Cancel</button>  <!-- new cass name cancel-btn-->
        </div> 
    </form>
</div>
    </div>
    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        
        $(document).ready(function() {
            $('#inventoryTable').on('click', '.edit-btn', function() {
    const inventoryId = $(this).data('id'); 
    // Load data from the server using AJAX
    $.ajax({
        url: 'get_inventory_details.php', 
        type: 'POST',
        data: { inventoryId: inventoryId },
        dataType: 'json',
        success: function(data) {
            $('#inventoryId').val(data.inventory_id);
            $('#bloodType').val(data.blood_type); 
            $('#quantity').val(data.quantity);
            $('#editFormContainer').show(); 
        }
    });
});

$('#editForm').submit(function(event) {
        event.preventDefault(); 

        const inventoryId = $('#inventoryId').val();
        const bloodType = $('#bloodType').val();
        const quantity = $('#quantity').val();

        $.ajax({
            url: 'update_inventory.php', 
            type: 'POST',
            data: { 
                inventoryId: inventoryId, 
                bloodType: bloodType, 
                quantity: quantity, 
            }, 
            success: function(response) {
                $('#editFormContainer').hide();
                console.log(response); 
                // Potentially refresh the inventory table using loadInventory() 
                const rowToUpdate = $('#inventoryTable').find('tr[data-id="' + inventoryId + '"]');
                if (quantity <= 10) { 
                    rowToUpdate.addClass('low-stock');
                } else {
                    rowToUpdate.removeClass('low-stock');
                }  

    // 2. Update cells within the row
                rowToUpdate.find('td:eq(0)').text(bloodType); // Update blood type (adjust column index if needed)
                rowToUpdate.find('td:eq(1)').text(quantity); // Update quantity 
}

        });
    });

// Close the form 
$('#editFormClose').click(function() {
    $('#editFormContainer').hide(); 
});

    loadInventory(); // Load the inventory data when the page loads
    $('#addNewInventory').click(function() {
        $('#addInventoryFormContainer').show(); 
    });

    // Close Form
    $('#addFormClose').click(function() {
        $('#addInventoryFormContainer').hide(); 
    });

    // Form Submission
    $('#addInventoryForm').submit(function(event) {
        event.preventDefault(); // Prevent default form submission

        const bloodTypeEdit = $('#bloodTypeEdit').val();
        const quantityEdit = $('#quantityEdit').val();
        console.log(bloodTypeEdit, quantityEdit);
        $.ajax({
            url: 'add_inventory.php', 
            type: 'POST',
            data: { 
                bloodTypeEdit: bloodTypeEdit, 
                quantityEdit: quantityEdit
            }, 
            success: function(response) {
                $('#addInventoryFormContainer').hide();
                console.log(response); // For debugging and to see the server response.
                if(response.success){
                const newRow = `
                <tr>
                    <td>${bloodTypeEdit}</td>
                    <td>${quantityEdit}</td>
                    <td><button class='edit-btn'>Edit</button></td>
                </tr>
                `;

                // Add the new row to the table body
                $('#inventoryTable tbody').append(newRow);
                } else{
                    alert("Particualar inventary cannot be added: " + response.error);
                }
            // Ideally, add the new row to the inventory table dynamically (See notes below)
            // Example (assuming your existing table update logic uses a function called 'updateInventoryTable'):
            }
        });
    });
});



function loadInventory() {
    $.ajax({
        url: 'filter_inventory.php', // Script to fetch all inventory data
        type: 'POST', 
        dataType: 'json',
        success: function(data) {
            updateInventoryTable(data); 
        }
    });
}

function updateInventoryTable(data) {
    const $tableBody = $('#inventoryTable tbody'); 
    $tableBody.empty(); // Clear existing rows

    $.each(data, function(index, item) {
        let rowClass = (item.quantity <= 10) ? 'low-stock' : ''; 
        let newRow = `<tr class="${rowClass}">
                            <td>${item.blood_type}</td>
                            <td>${item.quantity}</td>
                            <td><button class='edit-btn' data-id='${item.inventory_id}'>Edit</button></td>
                      </tr>`;

        $tableBody.append(newRow);
    });
    
}

    </script> 
</html>
