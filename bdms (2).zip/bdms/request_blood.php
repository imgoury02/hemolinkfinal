<?php
// Check if a session is already started before calling session_start()
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Rest of your session.php code follows
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Blood Bank Dashboard</title> 
    <style>
        #sidebar {
            position:relative;
            margin-top:-20px;
        }
        #content {
            position:relative;
            margin-left:210px;
        }
        @media screen and (max-width: 600px) {
            #content {
                position:relative;
                margin-left:300px;
                margin-right:auto;
            }
        }
        .block-anchor {
            color:red;
            cursor: pointer;
        }
        /* General Table Styling */
        table {
            border-collapse: collapse;
            width: 80%;
            margin-top: 20px;
            margin-left: 150px;
        }
        thead {
            background-color: black;
            color: white;
        }
        tbody {
            background-color: #f0f0f0;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        /* Low Stock Warning */
        .low-stock {
            background-color: #ffdddd; /* Light Red */
        }
        /* Optional: Styling for Edit Buttons  */
        .edit-btn {
            background-color: #4CAF50; /* Green */
            color: white;
            padding: 5px 10px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }
        /* Add Request Button */
        #addNewRequests {
            display: block;
            margin: 20px auto;
            background-color: black;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }
        /* Form Container */
        #addRequestFormContainer {
            display: flex;
            justify-content: space-between;
            background-color: #f0f0f0;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 60%; /* Adjusted width */
            margin: 20px auto;
        }
        /* Form */
        #addRequestForm {
            width: 100%;
        }
        #addRequestForm label {
            display: block;
            margin-bottom: 5px;
        }
        #addRequestForm select, 
        #addRequestForm input[type="text"], 
        #addRequestForm input[type="number"], 
        #addRequestForm textarea {
            width: calc(100% - 10px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 14px;
        }
        #addRequestForm textarea {
            resize: vertical;
            height: 100px;
        }
        /* Submit and Cancel Buttons */
        .button-container {
        display: flex;
        justify-content: space-between;
    }
        .add-btn {
        background-color: black; 
        color: white; 
        padding: 10px 20px; 
        text-align: center; 
        border-radius: 4px; 
        border: none; 
        cursor: pointer; 
    }

    .cancel-btn {
        background-color: red; 
        color: white; 
        padding: 10px 20px; 
        text-align: center; 
        border-radius: 4px; 
        border: none; 
        cursor: pointer; 
    }
    </style>
</head>
<body style="color:black;">
    <?php
    include 'conn.php';  
    include 'session.php'; 
    ?>

    <div id="header">
        <?php include 'hheader.php'; ?>
    </div>

    <div id="sidebar">
        <?php
        $active="request";
        include 'hsidebar.php'; ?>
    </div>
    <div id=content>

    <table id="requestTable">
        <thead>
            <tr>
                <th>Blood Type</th>
                <th>Quantity</th>
                <th>Patient ID</th>
                <th>Case</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php 
                if (isset($_SESSION['loggedin']) || $_SESSION['user_type'] == 'hospital') { 
                    // Retrieve Blood Bank Details
                    $user_id = $_SESSION['user_id']; 
                    $sql = "SELECT *
                    FROM blood_requests 
                    JOIN hospitals ON blood_requests.hospital_id = hospitals.id 
                    JOIN users ON hospitals.user_id = users.id
                    WHERE users.id = $user_id";
                    $result = mysqli_query($conn, $sql);

                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {  
                            //echo "<tr class='" . $class . "' data-id='" . $row['inventory_id'] . "'>";
                            echo "<td>" . $row['blood_type'] . "</td>";
                            echo "<td>" . $row['quantity'] . "</td>";
                            echo "<td>" . $row['patient_id'] .  "</td>";
                            echo "<td>" . $row['notes'] .  "</td>";
                            echo "<td>" . $row['status'] .  "</td>";
                            //echo "<td><button class='edit-btn' data-id='" . $row['inventory_id'] . "'>Edit</button></td>"; 
                            echo "</tr>"; 
                    }} else {
                        echo "<tr><td colspan='4'>No request found</td></tr>";
                    }}
                ?> 
            </tbody>
    </table>
    <button id="addNewRequests">Add Request</button>
    <div id="addRequestFormContainer" style="display: none;"> 
    <form id="addRequestForm" method="post">
        <label for="bloodType">Blood Type:</label>
        <select name="bloodType" id="bloodType">
            <option value="A+">A+</option>
            <option value="B+">B+</option>
            <option value="A-">A-</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
        </select>

        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" required><br><br>

        <label for="patient_id">Patient ID:</label>
        <input type="text" id="patient_id" name="patient_id" required><br><br>

        <label for="notes">Case</label>
        <textarea name="notes" id="notes"></textarea>

        <div class="button-container">   <!-- new div-->
            <button type="submit" class="add-btn">Submit Request</button>  <!-- new class name add-btn-->
            <button type="button" class="cancel-btn" id="addFormClose">Cancel</button>  <!-- new cass name cancel-btn-->
        </div> 
    </form>
</div>
    </div>
    </body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        
        $(document).ready(function() {
            

    loadRequest(); // Load the inventory data when the page loads
    $('#addNewRequests').click(function() {
        $('#addRequestFormContainer').show(); 
    });

    // Close Form
    $('#addFormClose').click(function() {
        $('#addRequestFormContainer').hide(); 
    });

    // Form Submission
    $('#addRequestForm').submit(function(event) {
        event.preventDefault(); // Prevent default form submission

        const bloodType = $('#bloodType').val();
        const quantity = $('#quantity').val();
        const notes = $('#notes').val();
        const patient_id = $('#patient_id').val();
        const status = 'Pending';
        console.log(bloodType, quantity, notes);
        $.ajax({
            url: 'submit_request.php', 
            type: 'POST',
            data: { 
                bloodType: bloodType, 
                quantity: quantity, 
                patient_id: patient_id,
                notes: notes,
                status: status
            }, 
            success: function(response) {
                $('#addRequestFormContainer').hide();
                console.log(response); // For debugging and to see the server response.
                const newRow = `
                <tr>
                    <td>${bloodType}</td>
                    <td>${quantity}</td>
                    <td>${patient_id}</td>
                    <td>${notes}</td>
                    <td>${status}</td>
                </tr>
                `;

                // Add the new row to the table body
                $('#requestTable tbody').append(newRow);
            // Ideally, add the new row to the inventory table dynamically (See notes below)
            // Example (assuming your existing table update logic uses a function called 'updateInventoryTable'):
            }
        });
    });

        });

function loadRequest() {
    $.ajax({
        url: 'filter_request.php', 
        dataType: 'json',
        success: function(data) {
            updateRequestTable(data); 
        }
    });
}

function updateRequestTable(data) {
    const $tableBody = $('#requestTable tbody'); 
    $tableBody.empty(); // Clear existing rows

    $.each(data, function(index, item) { 
        let newRow = `<tr class="${rowClass}">
                            <td>${item.blood_type}</td>
                            <td>${item.quantity}</td>
                            <td>${item.patient_id}</td>
                            <td>${item.notes}</td>
                            <td>${item.status}</td>
                      </tr>`;

        $tableBody.append(newRow);
    });
    
}

    </script> 
</html>
