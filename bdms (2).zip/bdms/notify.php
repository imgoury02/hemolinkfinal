<!DOCTYPE html>
<>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Blood Bank Dashboard</title> <style>
    #sidebar {position:relative;margin-top:-20px}
    #content {position:relative;margin-left:210px}
    @media screen and (max-width: 600px) {
        #content {
            position:relative;margin-left:auto;margin-right:auto;
        }
    }
    .block-anchor {
        color:red;
        cursor: pointer;
    }
    </style>
</head>
< style="color:black;">
    <?php
    include 'conn.php';  
    include 'session.php'; 
    ?>

    <div id="header">
        <?php include 'dhearder.php'; ?>
    </div>

    <div id="sidebar">
        <?php
        $active="notify";
        include 'dsidebar.php'; ?>
    </div>
    <?php
    include 'conn.php';
    $donorId = $_SESSION['donor_id'];
    $sql = "SELECT * FROM donor_requests WHERE donor_id = ? AND dismissed = false";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $donorId);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = $result->fetch_all(MYSQLI_ASSOC); 

    ?>
    <div id="content">
    <div id="notifications-container">
    </div>

    </div> </body>

    <script>
const notifications = <?php echo json_encode($notifications); ?>; 

notifications.forEach(notification => {
    const notificationHTML = `
        <div class="notification">
            <p><strong>Blood Bank Name:</strong> ${notification.blood_bank_name}</p>
            <p><strong>Contact:</strong> ${notification.blood_bank_contact}</p>
            <button class="dismiss-btn" data-notification-id="${notification.id}">Dismiss</button>
        </div>
    `;
    $('#notifications-container').append(notificationHTML);
});

$('.dismiss-btn').click(function() {
    const notificationId = $(this).data('notification-id'); 
    const notificationElement = $(this).closest('.notification');

    $.ajax({
        url: 'dismiss_notification.php', 
        type: 'POST',
        data: { notificationId: notificationId },
        success: function(response) {
            notificationElement.fadeOut(); // Or any other visual dismissal
        }
    });
});

    </script>
</html>
