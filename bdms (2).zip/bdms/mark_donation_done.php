<?php
include 'conn.php';

$donorId = $_POST['donorId'];

$sql = "UPDATE donors SET last_donated = CURRENT_DATE(), status = false WHERE id = ?"; 
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $donorId);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}
