<?php
include 'conn.php'; 

// 1. Check if bloodType is submitted
if (isset($_POST['bloodType'])) { 
    $bloodType = $_POST['bloodType'];
} else {
    echo "Error: bloodType not provided";
    exit(); 
}
error_log("Received Blood Type: " . (isset($_POST['bloodType']) ? $_POST['bloodType'] : 'None')); 



// 2. Get user_id (replace this placeholder with your actual logic)
$user_id = $_SESSION['user_id'];; // TEMPORARY: Replace with your REAL way to get the user ID

// 3. Prepare SQL Query (Safer, using prepared statement)
$sql = "SELECT * 
        FROM blood_inventory 
        JOIN blood_banks ON blood_inventory.blood_bank_id = blood_banks.id 
        JOIN users ON blood_banks.user_id = users.id
        WHERE blood_type = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $bloodType); 

// 4. Execute and Handle Errors
if (!$stmt->execute()) {
    echo "Error executing query: " . mysqli_error($conn);
    exit(); 
}

// 5. Fetch results & handle empty result
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $inventoryData = array();
    while ($row = $result->fetch_assoc()) {
        $inventoryData[] = $row;
    }
    echo json_encode($inventoryData); 
} else {
    echo "No data found";
}
