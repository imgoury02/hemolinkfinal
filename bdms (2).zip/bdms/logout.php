
<html>
<?php
session_start();
unset($_SESSION['login']);
session_destroy(); 
?>
<head>
    <title>Logout</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
            color: black; /* Changed text color to black */
            font-family: Arial, sans-serif;
        }
        h1 {
            font-size: 3em;
            margin-top: 1em;
        }
        a {
            font-size: 1.5em;
            margin-top: 1em;
            display: inline-block;
            background-color: black;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            border: 1px solid white;
            transition: background-color 0.3s, color 0.3s;
        }
        a:hover {
            background-color: white;
            color: black;
        }
        img {
            width: 150px; /* Adjusted image size */
            margin-bottom: 20px; /* Added margin below image */
        }
    </style>
</head>
<body>
    <img src="image/hemologo.png">
    <h1>THANK YOU</h1>
    <a href="home.php">Go to Home</a>
</body>