<?php
include 'conn.php'; 
// Fetch form data
$name=$_POST['name'];
$username=$_POST['username'];
$psw=$_POST['psw'];
$contact_no=$_POST['contact_no'];
$email=$_POST['email'];
$city=$_POST['city'];
$district=$_POST['district'];
$license_details=$_POST['license_details'];
// Input Validation (Start) 
if (empty(trim($_POST['name'])) || empty(trim($_POST['username'])) ||  empty(trim($_POST['email'])) || 
empty(trim($_POST['psw'])) || empty(trim($_POST['license_details'])) || empty(trim($_POST['city'])) || 
empty(trim($_POST['district'])) || empty(trim($_POST['psw-repeat']))) {
    echo "Please fill in all required fields."; 
    exit;
}

// Checking for same password
if ($_POST['psw'] !== $_POST['psw-repeat']) {
  echo "Passwords do not match.";
  exit;
}
// Username validation
if (!preg_match("/^[a-zA-Z0-9_-]+$/", $_POST['username'])) {  
  echo "Username can only contain letters, numbers, underscores, and hyphens.";
  exit;
}

if (strlen($_POST['username']) < 6) {  
  echo "Username must be at least 6 characters long.";
  exit;
}

// Email validation
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
  echo "Email is valid.";
} else {
  echo "Invalid email format.";
}
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $_POST['username']); 
$stmt->execute();
$stmt->store_result(); 

if ($stmt->num_rows > 0) {
    echo "Username already exists. Please choose another one.";
    exit;
}
// Validation for contact number
if (!preg_match("/^[0-9]{10}$/", $_POST['contact_no'])) { 
  echo "Invalid contact number format.";
  exit; 
}
// Password Hashing
$hashed_password = password_hash($_POST['psw'], PASSWORD_DEFAULT);

// ----- Insert into 'users' table ------
$user_type='blood_bank';
$stmt = $conn->prepare("INSERT INTO users (username, psw, email, user_type, contact_no, city, district) VALUES ('$username', '$hashed_password', '$email', '$user_type', '$contact_no', '$city', '$district')"); 

if ($stmt->execute()) {
    // Get the newly generated user_id
    $user_id = $conn->insert_id;

    // ----- Insert into 'blood_banks' table ------
    $stmt = $conn->prepare("INSERT INTO blood_banks (user_id, name, license_details, city, district) VALUES ('$user_id', '$name', '$license_details', '$city', '$district')"); 

    if ($stmt->execute()) {
        header("Location:bblogin.php");
    } else {
        echo "Error during blood bank registration.";
    }
} else {
    echo "Error during user creation.";
}

// Close statements and database connection
$stmt->close();
$conn->close();

