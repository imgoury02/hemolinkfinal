<?php
include 'conn.php'; 
// Fetch form data
$name=$_POST['name'];
$username=$_POST['username'];
$psw=$_POST['psw'];
$contact_no=$_POST['contact_no'];
$email=$_POST['email'];
$proof_of_identity=$_POST['proof_of_identity'];
$city=$_POST['city'];
$district=$_POST['district'];
$other_medical_info=$_POST['other_medical_info'];
$blood_group=$_POST['blood_group'];
$dob=$_POST['dob'];
$last_donated=$_POST['last_donated'];
// Input Validation (Start) 
if (empty(trim($_POST['name'])) || empty(trim($_POST['username'])) ||  empty(trim($_POST['email'])) || 
empty(trim($_POST['psw'])) || empty(trim($_POST['proof_of_identity'])) || empty(trim($_POST['city'])) || 
empty(trim($_POST['district'])) || empty(trim($_POST['psw-repeat'])) || empty(trim($_POST['blood_group'])) || empty(trim($_POST['dob']))
|| empty(trim($_POST['last_donated']))) {
    echo "Please fill in all required fields."; 
    exit;
}
// Checking for same password
if ($_POST['psw'] !== $_POST['psw-repeat']) {
  echo '<script>alert("Password does not match");window.location.href = "dregister.php";</script>';
  exit;
}
// Username validation
if (!preg_match("/^[a-zA-Z0-9_-]+$/", $_POST['username'])) {  
  echo '<script>alert("Username can only contain letters, numbers, underscores, and hyphens.");
  window.location.href = "dregister.php";</script>';
  exit;
}

if (strlen($_POST['username']) < 6) {  
  echo '<script>alert("Username must be at least 6 characters long.");window.location.href = "dregister.php";</script>';
  exit;
}
// Email validation
if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
  echo "Email is valid.";
} else {
  echo '<script>alert("Invalid email format.");window.location.href = "dregister.php";</script>';
}
$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
$stmt->bind_param("s", $_POST['username']); 
$stmt->execute();
$stmt->store_result(); 

if ($stmt->num_rows > 0) {
    echo '<script>alert("Username already exists. Please choose another one.");window.location.href = "dregister.php";</script>';
    exit;
}
// Validation for contact number
if (!preg_match("/^[0-9]{10}$/", $_POST['contact_no'])) { 
  echo '<script>alert("Invalid contact number format.");window.location.href = "dregister.php";</script>';
  exit; 
}

// Age Validation 
$birthDate = new DateTime($dob);
$today = new DateTime('today');
$age = $today->diff($birthDate)->y;

if ($age < 18) {
  echo '<script>alert("You must be 18 years old or above to register as a donor.");window.location.href = "dregister.php";</script>';
  exit;
}

// Validating Blood Groups
$validBloodGroups = array("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-");
if (!in_array($_POST['blood_group'], $validBloodGroups)) {
  echo '<script>alert("Invalid blood group. Please select a valid option (A+, A-, B+, B-, O+, O-, AB+, AB-).");window.location.href = "dregister.php";</script>';
  exit;
}

// Password Hashing
$hashed_password = password_hash($_POST['psw'], PASSWORD_DEFAULT);
$lastDonatedDate = strtotime($last_donated); 
$fourMonthsAgo = strtotime("-4 months");

if ($lastDonatedDate <= $fourMonthsAgo) {
    $status = true; 
} else {
    $status = false;
}

// ----- Insert into 'users' table ------
$user_type='donor';
$stmt = $conn->prepare("INSERT INTO users (username, psw, email, user_type, contact_no, city, district, proof_of_identity) VALUES ('$username', '$hashed_password', '$email', '$user_type', '$contact_no', '$city', '$district', '$proof_of_identity')"); 
if (!$stmt) {
  echo "Error preparing statement: " . mysqli_error($conn);
  exit(); // Stop script execution on error
}

if ($stmt->execute()) {
    // Get the newly generated user_id
    $user_id = $conn->insert_id;

    // ----- Insert into 'donors' table ------
    $stmt = $conn->prepare("INSERT INTO donors (user_id, name, dob, last_donated, blood_group, other_medical_info, status ) VALUES ('$user_id', '$name', '$dob', '$last_donated', '$blood_group', '$other_medical_info', '$status')"); 
    if ($stmt->execute()) {
        header("Location:dlogin.php");
    } else {
        echo "Error during donor registration.";
    }
} else {
    echo "Error during user creation: " . $stmt->error . " SQL: " . $stmt->sqlstate; 

}

// Close statements and database connection
$stmt->close();
$conn->close();
?>