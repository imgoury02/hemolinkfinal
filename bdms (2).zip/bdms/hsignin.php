<?php
include 'conn.php';

// ... (Input retrieval from form)
$username=$_POST['username'];
$psw=$_POST['psw'];
$stmt = $conn->prepare("SELECT id, psw, user_type FROM users WHERE username = '$username'");
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 1) {
   $stmt->bind_result($user_id, $hashed_password, $user_type);
   $stmt->fetch();

   if (password_verify($psw, $hashed_password)) {
       // Successful Login
       session_start(); 
       $_SESSION['user_id'] = $user_id;
       $_SESSION['user_type'] = $user_type;

       // Redirect based on user_type
       if ($user_type == 'hospital') {
          header("Location: hdash.php"); 
       }

    } else {
      echo '<script>alert("Invalid password"); window.location.href = "hlogin.php";</script>';
    }
} else {
   echo '<script>alert("Invalid username"); window.location.href = "hlogin.php";</script>';
}
?>